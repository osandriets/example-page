'use strict';

require('./main.scss');
// --------------- preloader -------------------------------

document.body.onload = function () {
    setTimeout(function () {
        let preloader = document.getElementById('page-preloader');
        if( !preloader.classList.contains('preloader--done')) {
            preloader.classList.add('preloader--done');
        }
    }, 2000);
}

// --------------- modal -------------------------------

let modal = document.getElementById('feedback');
let btn = document.getElementById("btnFeedback");
let span = document.getElementsByClassName("modal-content__close")[0];

btn.onclick = function() {
    modal.style.display = "block";
}

span.onclick = function() {
    modal.style.display = "none";
}

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

// ----------------- slider -----------------------------

let controls = document.querySelectorAll('.slider__control');
let slides = document.querySelectorAll('.slider .slider__item');
let currentSlide = 0;
let slideInterval = setInterval(nextSlide,4000);

for(let i=0; i<controls.length; i++){
    controls[i].style.display = 'inline-block';
}

function nextSlide(){
    goToSlide(currentSlide+1);
}

function previousSlide(){
    goToSlide(currentSlide-1);
}

function goToSlide(n){
    slides[currentSlide].className = 'slider__item';
    currentSlide = (n+slides.length)%slides.length;
    slides[currentSlide].className = 'slider__item slider__item--active';
}

let playing = true;
let next = document.getElementById('next');
let previous = document.getElementById('previous');

function pauseSlideshow(){
    playing = false;
    clearInterval(slideInterval);
}

next.onclick = function(){
    pauseSlideshow();
    nextSlide();
};
previous.onclick = function(){
    pauseSlideshow();
    previousSlide();
};
